//
//  SGAdverScrollView.h
//  HENGYING
//
//  Created by sgq on 2019/11/21.
//  Copyright © 2019 Abel. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol SGAdverScrollViewDelegate <NSObject>
//自定义样式
- (UICollectionViewCell *)SGAdverScrollViewCollectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath;

- (CGSize)SGAdverScrollViewcollectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath ;
- (void) SGSGAdverScrollViewDidSelctIndex:(int) index;
@end

@interface SGAdverScrollView : UIView
@property (nonatomic, strong) UICollectionView *collectionView;
//数据总数
@property (nonatomic, assign) int dataCount;
//跑马灯界面上展示几个数据 默认 2行
@property (nonatomic, assign) int showNum;

//一次滚动几行 默认一次展示1行
@property (nonatomic, assign) int  rowNum;

//禁止手势滑动
- (void)disableScrollGesture;

//代理
@property (nonatomic, assign) id <SGAdverScrollViewDelegate> delegate;
@end

NS_ASSUME_NONNULL_END
