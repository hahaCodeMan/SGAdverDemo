//
//  SGAdverScrollView.m
//  HENGYING
//
//  Created by sgq on 2019/11/21.
//  Copyright © 2019 Abel. All rights reserved.
//

#import "SGAdverScrollView.h"
#import "DemoCollectionViewCell.h"
@interface SGAdverScrollView()<UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout>

@property (nonatomic, strong) UICollectionViewFlowLayout *layout;
@property(nonatomic,strong)NSTimer *timer;

@end

@implementation SGAdverScrollView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        //添加collectionView
        [self addSubview:self.collectionView];
        self.showNum = 2;
        self.rowNum = 1;
    }
    return self;
}

-(UICollectionView *)collectionView{
    if (!_collectionView) {
        self.layout =[[UICollectionViewFlowLayout alloc]init];
        self.layout.minimumLineSpacing = 0;
        _collectionView = [[UICollectionView alloc]initWithFrame:self.bounds collectionViewLayout:self.layout];
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        _collectionView.scrollsToTop = NO;
        _collectionView.scrollEnabled = YES;
        _collectionView.showsVerticalScrollIndicator = NO;
        _collectionView.pagingEnabled = YES;
        _collectionView.bounces = NO;
        _collectionView.backgroundColor = [UIColor whiteColor];
       
    }
    return _collectionView;
}

- (void)setDataCount:(int)dataCount {
    _dataCount = dataCount;
    [self.collectionView reloadData];
    if (dataCount > 0) {
        [self.collectionView scrollToItemAtIndexPath:[NSIndexPath indexPathForItem:0 inSection:0] atScrollPosition:UICollectionViewScrollPositionBottom animated:NO];
        //添加定时器
        [self addTimer];
    }
    
}
//添加为common模式，UI变化不会影响定时器
-(void)addTimer{
    [self.timer invalidate];
    self.timer = nil;
    self.timer = [NSTimer timerWithTimeInterval:3.0 target:self selector:@selector(reloadView) userInfo:nil repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];
}
//刷新界面
- (void)reloadView {
    if (_dataCount == 0) {
        return;
    }
    //开辟了2个分区，第2个分区作为一个过渡
    // 1、当前正在展示的位置
    NSIndexPath *currentIndexPath;
    NSIndexPath *firstIndexPath = [[self.collectionView indexPathsForVisibleItems] firstObject];
    NSIndexPath *lastIndexPath = [[self.collectionView indexPathsForVisibleItems] lastObject];
    if (firstIndexPath.section == lastIndexPath.section) {
        currentIndexPath = firstIndexPath.row > lastIndexPath.row ? firstIndexPath : lastIndexPath;
    }else {
        currentIndexPath = firstIndexPath.section > lastIndexPath.section ? firstIndexPath : lastIndexPath;
    }
    NSIndexPath *resetCurrentIndexPath  = currentIndexPath;
    
    //马上显示回第一分区的数据
    if (currentIndexPath.section == 1 && currentIndexPath.row > 0) {
        resetCurrentIndexPath = [NSIndexPath indexPathForItem:currentIndexPath.item inSection:0];
        [self.collectionView scrollToItemAtIndexPath:resetCurrentIndexPath atScrollPosition:UICollectionViewScrollPositionBottom animated:NO];
    }
    // 2、计算出下一个需要展示的位置
    NSInteger nextItem = resetCurrentIndexPath.item + _rowNum;
    NSInteger nextSection = resetCurrentIndexPath.section;
    if (nextItem == _dataCount) {
        nextItem = 0;
        if (nextSection == 1) {
            nextSection = 0;
        }else {
            nextSection = 1;
        }
    }
    
    NSIndexPath *nextIndexPath = [NSIndexPath indexPathForItem:nextItem inSection:nextSection];
    
    // 3、通过动画滚动到下一个位置
    [self.collectionView scrollToItemAtIndexPath:nextIndexPath atScrollPosition:UICollectionViewScrollPositionBottom animated:YES];
}

-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 2;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.dataCount;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    if (self.delegate && [self.delegate respondsToSelector:@selector(SGAdverScrollViewCollectionView:cellForItemAtIndexPath: )]) {
           return [self.delegate SGAdverScrollViewCollectionView:collectionView cellForItemAtIndexPath:indexPath];
       }
 
    return nil;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
   if (self.delegate && [self.delegate respondsToSelector:@selector(SGAdverScrollViewcollectionView:layout:sizeForItemAtIndexPath:)]) {
          return [self.delegate SGAdverScrollViewcollectionView:collectionView layout:collectionViewLayout sizeForItemAtIndexPath:indexPath];
      }
    return CGSizeZero;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    if (self.delegate && [self.delegate respondsToSelector:@selector(SGSGAdverScrollViewDidSelctIndex:)]) {
             [self.delegate SGSGAdverScrollViewDidSelctIndex:(int)indexPath.row];
        }
    
}
- (void)disableScrollGesture {
    self.collectionView.canCancelContentTouches = NO;
    for (UIGestureRecognizer *gesture in self.collectionView.gestureRecognizers) {
        if ([gesture isKindOfClass:[UIPanGestureRecognizer class]]) {
            [self.collectionView removeGestureRecognizer:gesture];
        }
    }
}
@end
