//
//  DemoCollectionViewCell.m
//  VerScrolllDemo
//
//  Created by sgq on 2019/11/21.
//  Copyright © 2019 sgq. All rights reserved.
//

#import "DemoCollectionViewCell.h"

@implementation DemoCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
