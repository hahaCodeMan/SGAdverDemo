//
//  ViewController.m
//  VerScrolllDemo
//
//  Created by sgq on 2019/11/21.
//  Copyright © 2019 sgq. All rights reserved.
//

#import "ViewController.h"
#import "SGAdverScrollView.h"
#import "DemoCollectionViewCell.h"
@interface ViewController ()<SGAdverScrollViewDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    SGAdverScrollView *adView = [[SGAdverScrollView alloc] initWithFrame:CGRectMake(0, 100, [UIScreen mainScreen].bounds.size.width, 72)];
    adView.delegate = self;
    //设置展示行数
    adView.showNum = 3;
    //设置数据
    adView.dataCount = 7;
    [adView.collectionView registerNib:[UINib nibWithNibName:@"DemoCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:@"cell"];
    [self.view addSubview:adView];
}

#pragma mark ----- SGAdverScrollView代理 ------
- (CGSize)SGAdverScrollViewcollectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    return CGSizeMake( [UIScreen mainScreen].bounds.size.width, 36);
}

- (UICollectionViewCell *)SGAdverScrollViewCollectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    DemoCollectionViewCell *cell =[collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    cell.titleLabel.text = [NSString stringWithFormat:@"test----%ld",indexPath.row];
    return cell;
}

- (void)SGSGAdverScrollViewDidSelctIndex:(int)index {
    NSLog(@"点击了------%d 个", index);
}
@end
